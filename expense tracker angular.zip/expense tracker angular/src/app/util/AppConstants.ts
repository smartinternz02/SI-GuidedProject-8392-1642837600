import { tokenize } from "@angular/compiler/src/ml_parser/lexer";

export class AppConstants{
    public static ENDPOINT='http://localhost:8080';
    public static EXPENSE_CATEGORIES=['Clothing','Entertainment','Food','Fuel','Health','Salary','Misc'];
    public static token: string|null=null;

    static getToken(){
        if(this.token===null){
            this.token=localStorage.getItem('token');
        }
        return this.token;
    }

    static setToken(token:string){
        localStorage.setItem('token',token);
    }
}